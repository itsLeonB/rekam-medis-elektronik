<template>
    <img :src="'/storage/images/logo-rsum.png'">
</template>
