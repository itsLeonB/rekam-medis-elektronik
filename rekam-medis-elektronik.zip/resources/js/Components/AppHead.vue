<script setup>
import { Head } from '@inertiajs/vue3'
</script>

<template>
  <Head>
    <link rel="icon" type="image/x-icon" href="storage/images/logo-rsum.png">
    <slot />
  </Head>
</template>